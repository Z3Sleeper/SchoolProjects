package com.example.flashcardappv2;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.google.gson.Gson;

public class FlashcardManager {
    private static final String FLASHCARDS_PREFS = "flashcards_prefs";
    private static final String FLASHCARDS_KEY = "flashcards";

    private final List<Flashcard> flashcardList;
    private final SharedPreferences mPreferences;
    private final Gson gson;

    public FlashcardManager(Context context) {
        mPreferences = context.getSharedPreferences(FLASHCARDS_PREFS, Context.MODE_PRIVATE);
        gson = new Gson();
        flashcardList = loadFlashcards();
    }

    public void addFlashcard(Flashcard flashcard) {
        flashcardList.add(flashcard);
        saveFlashcards(flashcardList);
    }

    public void deleteFlashcard(int index) {
        if (index >= 0 && index < flashcardList.size()) {
            flashcardList.remove(index);
            saveFlashcards(flashcardList);
        }
    }

    public void editFlashcard(int index, String question, String answer) {
        if (index >= 0 && index < flashcardList.size()) {
            getFlashcard(index).setQuestion(question);
            getFlashcard(index).setAnswer(answer);
            saveFlashcards(flashcardList);
        }
    }

    public Flashcard getFlashcard(int index) {
        if (index >= 0 && index < flashcardList.size()) {
            return flashcardList.get(index);
        } else {
            return null;
        }
    }

    public int getSize() {
        return flashcardList.size();
    }

    public void saveFlashcards(List<Flashcard> flashcards) {
        String flashcardsJson = gson.toJson(flashcards);
        mPreferences.edit().putString(FLASHCARDS_KEY, flashcardsJson).apply();
    }

    public boolean isEmpty() {
        return flashcardList.size() == 0;
    }

    public List<Flashcard> loadFlashcards() {
        String flashcardsJson = mPreferences.getString(FLASHCARDS_KEY, null);
        if (flashcardsJson != null) {
            Flashcard[] flashcardsArray = gson.fromJson(flashcardsJson, Flashcard[].class);
            List<Flashcard> flashcardsList = new ArrayList<>();
            if (flashcardsArray != null) {
                flashcardsList.addAll(Arrays.asList(flashcardsArray));
            }
            return flashcardsList;
        }
        return new ArrayList<>();
    }
}
