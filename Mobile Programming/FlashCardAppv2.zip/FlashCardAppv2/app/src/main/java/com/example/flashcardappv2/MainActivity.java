package com.example.flashcardappv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void launchGridView(View v) { openGridViewActivity(); }

    public void openGridViewActivity() {
        Intent intent = new Intent(this, GridViewActivity.class);
        startActivity(intent);
    }
}