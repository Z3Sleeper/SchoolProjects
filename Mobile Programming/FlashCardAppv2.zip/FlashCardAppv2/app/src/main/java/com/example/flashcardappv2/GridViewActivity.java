package com.example.flashcardappv2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class GridViewActivity extends AppCompatActivity {

    private FlashcardManager manager;
    private ArrayAdapter<String> adapter;
    private GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_view);

        manager = new FlashcardManager(this);
        gridView = findViewById(R.id.grid_view);
        setupGridView();
    }

    @Override
    protected void onResume() {
        super.onResume();

        manager = new FlashcardManager(this);

        setupGridView();
    }

    public void launchAdd(View view) {
        Intent intent = new Intent(this, AddActivity.class);
        startActivity(intent);
    }

    private void setupGridView() {
        List<String> questionList = new ArrayList<>();
        for (int i = 0; i < manager.getSize(); i++) {
            questionList.add(manager.getFlashcard(i).getQuestion());
        }

        adapter = new ArrayAdapter<>(this, R.layout.grid_item, questionList);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(GridViewActivity.this, ViewActivity.class);
            intent.putExtra("edit_index", position); // Position of clicked object is equal to index
            startActivity(intent);
        });
    }

    public void exitGridView (View view) {
        finish();
    }
}