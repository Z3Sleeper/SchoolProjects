package com.example.flashcardappv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ViewActivity extends AppCompatActivity {

    private FlashcardManager manager;
    private int cardIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        manager = new FlashcardManager(this);
        cardIndex = getIntent().getIntExtra("edit_index", -1);;
    }

    @Override
    protected void onResume() {
        super.onResume();

        manager = new FlashcardManager(this);

        setupView();
    }

    public void setupView() {
        TextView questionText = findViewById(R.id.question);
        String question = manager.getFlashcard(cardIndex).getQuestion();
        questionText.setText(question);
        TextView answerText = findViewById(R.id.answer);
        answerText.setText("");
    }

    public void showAnswer (View view) {
        TextView answerText = findViewById(R.id.answer);
        String answer = manager.getFlashcard(cardIndex).getAnswer();
        answerText.setText(answer);
    }

    public void nextQuestion (View view) {
        cardIndex++;
        TextView questionText = findViewById(R.id.question);
        TextView answerText = findViewById(R.id.answer);
        answerText.setText("");

        if (manager.getFlashcard(cardIndex) != null) {
            String question = manager.getFlashcard(cardIndex).getQuestion();
            questionText.setText(question);
        } else {
            cardIndex = 0;
            String question = manager.getFlashcard(cardIndex).getQuestion();
            questionText.setText(question);
        }
    }

    public void prevQuestion (View view) {
        cardIndex--;
        TextView questionText = findViewById(R.id.question);
        TextView answerText = findViewById(R.id.answer);
        answerText.setText("");

        if (manager.getFlashcard(cardIndex) != null) {
            String question = manager.getFlashcard(cardIndex).getQuestion();
            questionText.setText(question);
        } else {
            cardIndex = manager.getSize() - 1;
            String question = manager.getFlashcard(cardIndex).getQuestion();
            questionText.setText(question);
        }
    }

    public void deleteFlashcard(View view) {
        manager.deleteFlashcard(cardIndex);
        Toast.makeText(this, R.string.delete_message, Toast.LENGTH_SHORT).show();

        if (!manager.isEmpty()) {
            cardIndex--;
            nextQuestion(view);
        } else {
            finish();
        }
    }

    public void launchEdit(View view) {
        Intent intent = new Intent(this, EditActivity.class);
        intent.putExtra("edit_index", cardIndex);
        startActivity(intent);
    }

    public void exitView (View view) {
        finish();
    }
}