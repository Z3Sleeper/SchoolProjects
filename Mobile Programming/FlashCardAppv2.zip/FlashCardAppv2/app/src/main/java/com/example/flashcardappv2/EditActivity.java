package com.example.flashcardappv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity {

    private FlashcardManager manager;
    private int editIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);


        manager = new FlashcardManager(this);
        editIndex = getIntent().getIntExtra("edit_index", -1);

        EditText questionEdit = findViewById(R.id.question);
        EditText answerEdit = findViewById(R.id.answer);

        questionEdit.setText(manager.getFlashcard(editIndex).getQuestion());
        answerEdit.setText(manager.getFlashcard(editIndex).getAnswer());
    }

    public void saveEdit (View view) {
        EditText questionEdit = findViewById(R.id.question);
        EditText answerEdit = findViewById(R.id.answer);

        String question = questionEdit.getText().toString();
        String answer = answerEdit.getText().toString();

        if (!question.isEmpty() && !answer.isEmpty()) {
            manager.editFlashcard(editIndex, question, answer);
            Toast.makeText(this, R.string.save_message, Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, R.string.fill_out_fields, Toast.LENGTH_SHORT).show();
        }
    }

    public void exitEdit (View view) {
        finish();
    }
}