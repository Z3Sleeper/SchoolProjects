package com.example.clickthegreenone;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.Path;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.view.WindowManager;
import android.widget.TextView;

import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private FrameLayout containerLayout;
    private int numGreenSquares;
    private int numRedSquares;
    private int aliveGreenSquares;
    private int points;
    private int strikes;
    private DisplayMetrics displayMetrics;
    private WindowManager windowManager;
    private int screenWidth;
    private int screenHeight;
    private TextView scoreTextView;
    private TextView strikeTextView;
    private Button startButton;
    private HighScoreManager highScoreManager;
    private TextView highScoresTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        highScoreManager = new HighScoreManager(this);

        containerLayout = findViewById(R.id.containerLayout);

        scoreTextView = findViewById(R.id.scoreTextView);
        strikeTextView = findViewById(R.id.strikeTextView);
        startButton = findViewById(R.id.startButton);
        highScoresTextView = findViewById(R.id.highScoresTextView);

        displayMetrics = new DisplayMetrics();
        windowManager = getWindowManager();
        windowManager.getDefaultDisplay().getMetrics(displayMetrics);
        screenWidth = displayMetrics.widthPixels;
        screenHeight = displayMetrics.heightPixels;

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startButton.setVisibility(View.GONE);
                numGreenSquares = 2;
                numRedSquares = 2;
                aliveGreenSquares = 0;
                points = 0;
                strikes = 0;

                updateScore();
                updateStrikes();
                startGame();
            }
        });
    }

    private void startGame() {
        numGreenSquares++;
        numRedSquares++;
        aliveGreenSquares = numGreenSquares;

        containerLayout.removeAllViews();

        containerLayout.addView(scoreTextView);
        containerLayout.addView(strikeTextView);

        for (int i = 0; i < numGreenSquares; i++) {
            addSquare(R.color.green);
        }
        for (int i = 0; i < numRedSquares; i++) {
            addSquare(R.color.red);
        }
    }

    private void endGame() {
        containerLayout.removeAllViews();

        containerLayout.addView(scoreTextView);
        containerLayout.addView(strikeTextView);
        containerLayout.addView(startButton);

        startButton.setVisibility(View.VISIBLE);
        highScoreManager.addScore(points);
        List<Integer> highScoresList = highScoreManager.getHighScores();
        StringBuilder highScoresText = new StringBuilder();

        highScoresText.append("HIGHEST POINTS\n");
        int position;
        for (int i = 0; i < highScoresList.size(); i++) {
            position = i + 1;
            highScoresText.append(position).append(": ").append(highScoresList.get(i)).append("\n");
        }

        containerLayout.addView(highScoresTextView);
        highScoresTextView.setText(highScoresText.toString());
    }

    private void updateScore() {
        String scoreUIText = getString(R.string.score_ui);
        String scoreText = scoreUIText + " " + points;
        scoreTextView.setText(scoreText);
    }

    private void updateStrikes() {
        String strikeUIText;
        if (strikes == 0) {
            strikeUIText = "O O O";
        } else if (strikes == 1) {
            strikeUIText = "X O O";
        } else if (strikes == 2) {
            strikeUIText = "X X O";
        } else {
            strikeUIText = "X X X";
        }
        strikeTextView.setText(strikeUIText);

        if (strikes >= 3) {
            endGame();
        }
    }

    private void addSquare(int color) {
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(R.drawable.square);
        imageView.setColorFilter(ContextCompat.getColor(this, color));
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (color == R.color.green) {
                    points++;
                    aliveGreenSquares--;
                    updateScore();
                    if (aliveGreenSquares == 0) {
                        strikes = 0;
                        updateStrikes();
                        startGame();
                    }
                    containerLayout.removeView(v);
                } else {
                    strikes++;
                    updateStrikes();
                    containerLayout.removeView(v);
                }
            }
        });

        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                300,
                300
        );

        Random random = new Random();
        int maxX = screenWidth - 100;
        int maxY = screenHeight - 500;
        int randomX = random.nextInt(maxX);
        int randomY = random.nextInt(maxY) + 500;

        layoutParams.leftMargin = randomX;
        layoutParams.topMargin = randomY;

        containerLayout.addView(imageView, layoutParams);

        float centerX = layoutParams.leftMargin + imageView.getWidth() / 2;
        float centerY = layoutParams.topMargin + imageView.getHeight() / 2;

        animateSquare(imageView, centerX, centerY, color);
    }

    private void animateSquare(View view, float centerX, float centerY, int color) {
        Path path = new Path();
        Random random = new Random();
        if (color == R.color.green) {
            path.addCircle(centerX, centerY, random.nextFloat() * 600 + 200, Path.Direction.CW);
        } else {
            path.addCircle(centerX, centerY, random.nextFloat() * 600 + 200, Path.Direction.CCW);
        }

        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(view, View.X, View.Y, path);
        long randomDuration = (long) (random.nextInt(2000) + 3000);
        objectAnimator.setDuration(randomDuration);
        objectAnimator.setInterpolator(new LinearInterpolator());
        objectAnimator.setRepeatCount(ValueAnimator.INFINITE);
        objectAnimator.start();
    }
}
