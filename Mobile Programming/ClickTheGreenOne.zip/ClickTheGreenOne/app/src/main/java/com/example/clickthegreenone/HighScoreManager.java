package com.example.clickthegreenone;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HighScoreManager {

    private static final String PREF_NAME = "HighScorePrefs";
    private static final String KEY_HIGH_SCORES = "high_scores";
    private static final int MAX_HIGH_SCORES = 5;

    private SharedPreferences mPreferences;

    public HighScoreManager(Context context) {
        mPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public List<Integer> getHighScores() {
        List<Integer> highScores = new ArrayList<>();
        String scoresString = mPreferences.getString(KEY_HIGH_SCORES, "");
        if (!scoresString.isEmpty()) {
            String[] scoresArray = scoresString.split(",");
            for (String score : scoresArray) {
                highScores.add(Integer.parseInt(score));
            }
        }
        return highScores;
    }

    public void saveHighScores(List<Integer> highScores) {
        StringBuilder scoresString = new StringBuilder();
        for (int i = 0; i < Math.min(highScores.size(), MAX_HIGH_SCORES); i++) {
            scoresString.append(highScores.get(i)).append(",");
        }
        mPreferences.edit().putString(KEY_HIGH_SCORES, scoresString.toString()).apply();
    }

    public void addScore(int score) {
        List<Integer> highScores = getHighScores();
        highScores.add(score);
        Collections.sort(highScores, Collections.reverseOrder());
        saveHighScores(highScores);
    }
}