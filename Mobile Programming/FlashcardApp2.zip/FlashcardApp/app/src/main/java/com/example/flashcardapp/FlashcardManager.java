package com.example.flashcardapp;

import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public class FlashcardManager implements Serializable {
    private final List<Flashcard> flashcardList;

    public FlashcardManager() {
        this.flashcardList = new ArrayList<>();
    }

    public void addFlashcard(Flashcard flashcard) {
        flashcardList.add(flashcard);
    }

    public void deleteFlashcard(int index) {
        if (index >= 0 && index < flashcardList.size()) {
            flashcardList.remove(index);
        } else {
            System.out.println("Invalid index. Cannot delete");
        }
    }

    public void editFlashcard(int index, String question, String answer) {
        if (index >= 0 && index < flashcardList.size()) {
            getFlashcard(index).setQuestion(question);
            getFlashcard(index).setAnswer(answer);
        } else {
            System.out.println("Invalid index. Cannot edit.");
        }
    }

    public Flashcard getFlashcard(int index) {
        if (index >= 0 && index < flashcardList.size()) {
            return flashcardList.get(index);
        } else {
            return null;
        }
    }

    public List<Flashcard> getAllFlashcards() {
        return new ArrayList<>(flashcardList);
    }

    public int getSize() {
        return flashcardList.size();
    }
}
