package com.example.flashcardapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class DeleteActivity extends AppCompatActivity {

    private FlashcardManager manager;
    private int cardCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        // Retrieve the FlashcardManager object from the Intent extras
        manager = (FlashcardManager) getIntent().getSerializableExtra("flashcard_manager");

        cardCount = 0;
        TextView questionText = findViewById(R.id.question);
        String question = manager.getFlashcard(cardCount).getQuestion();
        questionText.setText(question);
        TextView answerText = findViewById(R.id.answer);
        String answer = manager.getFlashcard(cardCount).getAnswer();
        answerText.setText(answer);
    }

    public void deleteThis (View view) {
        manager.deleteFlashcard(cardCount);
        Toast.makeText(this, R.string.delete_message, Toast.LENGTH_SHORT).show();

        // Go to the next question or exit if we deleted everything
        if (!manager.getAllFlashcards().isEmpty()) {
            cardCount--;
            nextQuestion(view);
        } else {
            exitDelete(view);
        }
    }

    public void nextQuestion (View view) {
        cardCount++;
        TextView questionText = findViewById(R.id.question);
        TextView answerText = findViewById(R.id.answer);

        if (manager.getFlashcard(cardCount) != null) {
            String question = manager.getFlashcard(cardCount).getQuestion();
            questionText.setText(question);
            String answer = manager.getFlashcard(cardCount).getAnswer();
            answerText.setText(answer);
        } else {
            cardCount = 0;
            String question = manager.getFlashcard(cardCount).getQuestion();
            questionText.setText(question);
            String answer = manager.getFlashcard(cardCount).getAnswer();
            answerText.setText(answer);
        }
    }

    public void prevQuestion (View view) {
        cardCount--;
        TextView questionText = findViewById(R.id.question);
        TextView answerText = findViewById(R.id.answer);

        if (manager.getFlashcard(cardCount) != null) {
            String question = manager.getFlashcard(cardCount).getQuestion();
            questionText.setText(question);
            String answer = manager.getFlashcard(cardCount).getAnswer();
            answerText.setText(answer);
        } else {
            cardCount = manager.getSize() - 1;
            String question = manager.getFlashcard(cardCount).getQuestion();
            questionText.setText(question);
            String answer = manager.getFlashcard(cardCount).getAnswer();
            answerText.setText(answer);
        }
    }

    public void exitDelete (View view) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("modified_flashcard_manager", manager);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}