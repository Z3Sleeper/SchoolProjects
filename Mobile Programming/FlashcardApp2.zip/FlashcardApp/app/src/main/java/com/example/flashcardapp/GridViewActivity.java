package com.example.flashcardapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class GridViewActivity extends AppCompatActivity {

    private FlashcardManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_view);

        // Retrieve the FlashcardManager object from the Intent extras
        manager = (FlashcardManager) getIntent().getSerializableExtra("flashcard_manager");

        List<String> questionList = new ArrayList<>();
        for (int i = 0; i < manager.getSize(); i++) {
            questionList.add(manager.getFlashcard(i).getQuestion());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.grid_item, questionList);
        GridView gridView = findViewById(R.id.grid_view);
        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("modified_flashcard_manager", manager);
                resultIntent.putExtra("edit_index", position); // Position of clicked object is equal to index
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        });
    }

    public void exitGridView (View view) {
        finish();
    }
}
