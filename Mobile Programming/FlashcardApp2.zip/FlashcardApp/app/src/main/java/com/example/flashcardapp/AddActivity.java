package com.example.flashcardapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddActivity extends AppCompatActivity {

    private FlashcardManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        // Retrieve the FlashcardManager object from the Intent extras
        manager = (FlashcardManager) getIntent().getSerializableExtra("flashcard_manager");
    }

    public void saveFlashcard (View view) {
        EditText questionEdit = findViewById(R.id.question);
        EditText answerEdit = findViewById(R.id.answer);

        String question = questionEdit.getText().toString();
        String answer = answerEdit.getText().toString();

        if (!question.isEmpty() && !answer.isEmpty()) {
            Flashcard flashcard = new Flashcard(question, answer);
            manager.addFlashcard(flashcard);
            questionEdit.setText("");
            answerEdit.setText("");
            Toast.makeText(this, R.string.save_message, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.fill_out_fields, Toast.LENGTH_SHORT).show();
        }
    }

    public void exitAdd (View view) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("modified_flashcard_manager", manager);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}