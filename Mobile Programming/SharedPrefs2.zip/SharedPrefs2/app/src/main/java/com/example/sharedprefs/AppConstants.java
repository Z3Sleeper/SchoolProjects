package com.example.sharedprefs;

public class AppConstants {
    public static final String COUNT_KEY = "count";
    public static final String COLOR_KEY = "color";
}
