package com.example.sharedprefs;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class SettingsActivity extends AppCompatActivity {

    private SharedPreferences mPreferences;
    private String sharedPrefFile = "com.example.android.sharedprefs";

    private ToggleButton toggleCount;
    private EditText countValue;
    private ToggleButton toggleColor;
    private Spinner colorSpinner;
    private Button saveButton;
    private Button resetButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);

        toggleCount = findViewById(R.id.toggleCount);
        countValue = findViewById(R.id.countValue);
        toggleColor = findViewById(R.id.toggleColor);
        colorSpinner = findViewById(R.id.colorSpinner);
        saveButton = findViewById(R.id.saveButton);
        resetButton = findViewById(R.id.resetButton);

        // Initialize the color spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.colors,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        colorSpinner.setAdapter(adapter);

        // Load and display preferences
        loadPreferences();

        // Handle Save button click
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                savePreferences();
            }
        });

        // Handle Reset button click
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetPreferences();
            }
        });
    }

    // Load and display preferences
    private void loadPreferences() {
        // code to load the preferences goes here
        countValue.setText(String.valueOf(mPreferences.getInt(AppConstants.COUNT_KEY, 0)));
        int colorId = mPreferences.getInt(AppConstants.COLOR_KEY, ContextCompat.getColor(this, R.color.default_background));
        String[] colors = getResources().getStringArray(R.array.colors);
        for (int i = 0; i < colors.length; i++) {
            if (getColorIdByName(colors[i]) == colorId){
                colorSpinner.setSelection(i);
                break;
            }
        }
    }

    // Handle Save button click
    private void savePreferences() {
        // code to save the preferences goes here
        SharedPreferences.Editor editor = mPreferences.edit();
        if (toggleCount.isChecked()) {
            editor.putInt(AppConstants.COUNT_KEY, Integer.parseInt(countValue.getText().toString()));
        }
        if (toggleColor.isChecked()) {
            editor.putInt(AppConstants.COLOR_KEY, getColorIdByName((String) colorSpinner.getSelectedItem()));
        }
        editor.apply();
    }

    // Handle Reset button click
    private void resetPreferences() {
        // code to reset the preferences goes here
        toggleCount.setChecked(false);
        countValue.setText("0");
        toggleColor.setChecked(false);
        colorSpinner.setSelection(0);
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.clear();
        editor.apply();
    }

    // Helper method to get color resource ID by name
    private int getColorIdByName(String colorName) {
        switch (colorName) {
            case "Red":
                return ContextCompat.getColor(this, R.color.red_background);
            case "Blue":
                return ContextCompat.getColor(this, R.color.blue_background);
            case "Green":
                return ContextCompat.getColor(this, R.color.green_background);
            case "Black":
                return ContextCompat.getColor(this, R.color.black_background);
            default:
                return ContextCompat.getColor(this, R.color.default_background);
        }
    }
}
