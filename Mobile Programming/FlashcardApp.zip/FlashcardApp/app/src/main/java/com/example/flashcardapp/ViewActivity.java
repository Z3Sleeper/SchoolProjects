package com.example.flashcardapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ViewActivity extends AppCompatActivity {

    private FlashcardManager manager;
    private int cardCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);

        // Retrieve the FlashcardManager object from the Intent extras
        manager = (FlashcardManager) getIntent().getSerializableExtra("flashcard_manager");

        cardCount = getIntent().getIntExtra("edit_index", -1);;
        TextView questionText = findViewById(R.id.question);
        String question = manager.getFlashcard(cardCount).getQuestion();
        questionText.setText(question);
    }

    public void showAnswer (View view) {
        TextView answerText = findViewById(R.id.answer);
        String answer = manager.getFlashcard(cardCount).getAnswer();
        answerText.setText(answer);
    }

    public void nextQuestion (View view) {
        cardCount++;
        TextView questionText = findViewById(R.id.question);
        TextView answerText = findViewById(R.id.answer);
        answerText.setText("");

        if (manager.getFlashcard(cardCount) != null) {
            String question = manager.getFlashcard(cardCount).getQuestion();
            questionText.setText(question);
        } else {
            cardCount = 0;
            String question = manager.getFlashcard(cardCount).getQuestion();
            questionText.setText(question);
        }
    }

    public void prevQuestion (View view) {
        cardCount--;
        TextView questionText = findViewById(R.id.question);
        TextView answerText = findViewById(R.id.answer);
        answerText.setText("");

        if (manager.getFlashcard(cardCount) != null) {
            String question = manager.getFlashcard(cardCount).getQuestion();
            questionText.setText(question);
        } else {
            cardCount = manager.getSize() - 1;
            String question = manager.getFlashcard(cardCount).getQuestion();
            questionText.setText(question);
        }
    }

    public void launchEdit(View v) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("edit_index", cardCount);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    public void exitView (View view) {
        finish();
    }
}