package com.example.flashcardapp;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private FlashcardManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        manager = new FlashcardManager();
    }

    public void launchView(View v) { openViewActivity(manager, 0); }

    public void launchAdd(View v) { openAddActivity(manager); }

    public void launchDelete(View v) { openDeleteActivity(manager); }

    public void openViewActivity(FlashcardManager manager, int index) {
        if (!manager.getAllFlashcards().isEmpty()) {
            Intent intent = new Intent(this, ViewActivity.class);
            intent.putExtra("flashcard_manager", manager);
            intent.putExtra("edit_index", index);
            flashcardResultLauncher.launch(intent);
        } else {
            // Handle case where the manager is empty
            Toast.makeText(this, R.string.create_some_first, Toast.LENGTH_SHORT).show();
        }
    }

    public void openDeleteActivity(FlashcardManager manager) {
        if (!manager.getAllFlashcards().isEmpty()) {
            Intent intent = new Intent(this, DeleteActivity.class);
            intent.putExtra("flashcard_manager", manager);
            flashcardResultLauncher.launch(intent);
        } else {
            // Handle case where the manager is empty
            Toast.makeText(this, R.string.create_some_first, Toast.LENGTH_SHORT).show();
        }
    }

    public void openAddActivity(FlashcardManager manager) {
        Intent intent = new Intent(this, AddActivity.class);
        intent.putExtra("flashcard_manager", manager);
        flashcardResultLauncher.launch(intent);
    }

    public void openEditActivity(FlashcardManager manager, int index) {
        Intent intent = new Intent(this, EditActivity.class);
        intent.putExtra("flashcard_manager", manager);
        intent.putExtra("edit_index", index);
        flashcardResultLauncher.launch(intent);
    }

    ActivityResultLauncher<Intent> flashcardResultLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    new ActivityResultCallback<ActivityResult>() {
                        @Override
                        public void onActivityResult(ActivityResult result) {
                            if (result.getResultCode() == Activity.RESULT_OK) {
                                // There are no request codes
                                Intent data = result.getData();
                                if (data != null && data.hasExtra("modified_flashcard_manager") && data.hasExtra("edit_index")) {
                                    manager = (FlashcardManager) data.getSerializableExtra("modified_flashcard_manager");
                                    int editIndex = data.getIntExtra("edit_index", -1);
                                    openViewActivity(manager, editIndex);
                                }
                                else if (data != null && data.hasExtra("modified_flashcard_manager")) {
                                    manager = (FlashcardManager) data.getSerializableExtra("modified_flashcard_manager");
                                } else if (data != null && data.hasExtra("edit_index")) {
                                    int editIndex = data.getIntExtra("edit_index", -1);
                                    openEditActivity(manager, editIndex);
                                }
                            }
                        }
                    });

}