package com.example.flashcardapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class EditActivity extends AppCompatActivity {

    private FlashcardManager manager;
    private int editIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        // Retrieve the FlashcardManager object and index integer from the Intent extras
        manager = (FlashcardManager) getIntent().getSerializableExtra("flashcard_manager");
        editIndex = getIntent().getIntExtra("edit_index", -1);

        EditText questionEdit = findViewById(R.id.question);
        EditText answerEdit = findViewById(R.id.answer);

        questionEdit.setText(manager.getFlashcard(editIndex).getQuestion());
        answerEdit.setText(manager.getFlashcard(editIndex).getAnswer());
    }

    public void saveEdit (View view) {
        EditText questionEdit = findViewById(R.id.question);
        EditText answerEdit = findViewById(R.id.answer);

        String question = questionEdit.getText().toString();
        String answer = answerEdit.getText().toString();

        manager.editFlashcard(editIndex, question, answer);

        Intent resultIntent = new Intent();
        resultIntent.putExtra("modified_flashcard_manager", manager);
        resultIntent.putExtra("edit_index", editIndex);
        setResult(RESULT_OK, resultIntent);
        finish();
    }

    public void exitEdit (View view) {
        Intent resultIntent = new Intent();
        resultIntent.putExtra("modified_flashcard_manager", manager);
        resultIntent.putExtra("edit_index", editIndex);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}